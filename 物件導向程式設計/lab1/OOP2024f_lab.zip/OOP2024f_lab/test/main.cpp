#include "Util.hpp"
#include "Pacman.hpp"
#include "Blinky.hpp"
#include "Inky.hpp"
#include "Clyde.hpp"
#include "Pinky.hpp"

int main(){
    struct Point point(0,0);
    struct Point point1(15,15);
    struct Point point2(0,15);
    struct Point point3(7,7);
    struct Point point4(10,10);
    Draw(point,point1,point2,point3,point4);
    Blinky blinky = Blinky("B",point);
    Inky inky = Inky("I",point1);
    Pinky pinky = Pinky("P",point2);
    Clyde clyde = Clyde("C",point3);
    Pacman pacman = Pacman("P",point4);

    for (int i = 0;i<500;i++) {
        pacman.DoBehavior(pacman.GetPosition());


    }
}